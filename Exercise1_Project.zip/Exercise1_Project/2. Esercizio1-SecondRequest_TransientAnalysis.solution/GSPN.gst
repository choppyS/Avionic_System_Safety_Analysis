3 3
1 5 P
 &
 c = p 14 i 0
 &
 c = p 15 i 0
 c = p 16 i 1
2 5 P
 &
 c = p 15 i 0
 &
 c = p 16 i 0
 c = p 14 i 1
3 5 P
 &
 c = p 14 i 0
 &
 c = p 16 i 0
 c = p 15 i 1
1 1 MEASURE3
  o P 1
2 1 MEASURE4
  o P 2
3 1 MEASURE5
  o P 3
